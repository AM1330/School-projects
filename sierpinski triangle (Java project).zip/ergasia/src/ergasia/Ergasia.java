/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia;



/**
 *klash pou periexei thn main kai thn klhsh tou constructor tou para8yrou
 * @author ALEXANDROS
 */
public class Ergasia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args )  {
        
        
        window w= new window();
        w.setVisible(true);
        
        
        
    }
}
