/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia;

/**
 * klash pou perigrafei ena antikeimeno typou point gia thn dhmiourgia tou 
 * shmeiou me vash tis synistwses
 * @author ALEXANDROS
 */
public class Point {
     public int x,y;
    /**
     * 
     * @param x_co h x synistwsa tou shmeiou point
     * @param y_co h y synistwsa tou shmeiou point
     */
   public Point(int x_co,int y_co){
        x=x_co;
        y=y_co;
       
    }
   
  
    
    
    
}
